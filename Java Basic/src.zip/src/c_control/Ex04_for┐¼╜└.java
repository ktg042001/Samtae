//package c_control;
//
//import java.util.Scanner;
//
//public class Ex04_for연습 {
//
////	public static void main(String[] args) {
////		
//////		System.out.println( "정수입력"); 
//////		Scanner input = new Scanner(System.in); //숫자입력받을 가상통로
//////		int n = input.nextInt();//숫자 입력받아서 변수n저장
//////		
//////	
////		for(int i=1;i<=n;i++) {
////			System.out.print(i +" ");
////				if(i%5==0) {
////				System.out.println("");
////			}
////			
//		//문자열처리하기
//
//		//문자 N(a~z, A~Z)를 입력받아 N이 소문자면 a부터 N까지 인쇄하고
//		//N이 대문자이면 문자 N부터  Z까지 출력하라
//		//그 밖의 문자가 입력되면 Error 를 출력하라
//		
////		System.out.println("문자입력"); 
////		Scanner input = new Scanner(System.in); 
////		char n = input.nextLine().charAt(0);
////		
////		for(char b ='a' ; b<=n; b++) {
////			System.out.println(b);
//		
////		 Scanner scanner = new Scanner(System.in);//통로
////	      
////	      System.out.println("문자 하나 입력"); // 
////	      char n=scanner.next().charAt(0);
////	      
////	      if(n>='A' && n<='Z') {		
////	         for(char i=n; i<='Z' ;i++) {
////	            System.out.print(i + " ");
////	         }
////	         
////	      }else if(n>= 'a' && n<='z') {
////	         for(char i='a'; i<=n; i++) {
////	            System.out.print(i + " ");
////	         }
////	         
////	      }else{
////	         System.out.println("Error");
////	      }
////	      //문자열처리하기
//
//		//문자 N(a~z, A~Z)를 입력받아 N이 소문자면 a부터 N까지 인쇄하고
//		//N이 대문자이면 문자 N부터  Z까지 출력하라
//		//그 밖의 문자가 입력되면 Error 를 출력하라
//
//		Scanner input = new Scanner(System.in);
//		char c = input.next().charAt(0);
//		if( c >='a')
//		}
//		
//		
//		
//		
//	}



