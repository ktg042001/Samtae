//package c_control;
//
//import java.util.Scanner;
//
//public class Ex04_for연습1 {
//
//	public static void main(String[] args) {
////		//	-문자하나 입력받기
//		System.out.println("문자 하나 입력 ->");
//		Scanner sc = new Scanner(System.in);
//		char N = sc.nextLine().charAt(0);; // "D"
//		//	-입력한 문자가 대문자라면
//			if('A' <= N && N <='Z'){
//					for(char ch=N; ch<='Z';ch++)
//							System.out.println(ch);
//			}
//		//	-그렇지 않고 입력한 문자가 소문자라면
//			else if('a'<=N && N<='z') {
//				for(char ch='a';ch<=N;ch++) {
//					System.out.println(ch);
//				}
//			}
//				
//				
//		//	-그외라면
//			else {
//	
//			}
		
//			Scanner input =new Scanner(System.in);
//			System.out.println("문자열을 입력해 주세요");
//			String line="";//입력받은 문자열 저장 변수
//			line=input.nextLine();//입력 받음
//			int l_line= line.length();//문자열의 길이 입력 변수
//
//			for(int i = l_line-1;     i>=0;    i--) 
//				System.out.print(line.charAt(i));
//			for(int i = l_line;        i>0;    i--) {
//					System.out.print(line.charAt(i-1));
//		}
//		//문자열에 맨 뒤 주소 즉 lenght-1 부터 0 위치 까지 (반복)한 글자씩 뽑아서 출력한다.
//		//맨 끝자리 주소 부터 맨 앞 주소까지 한글자씩 뽑아서 입력
//		//주의 legnth는 글자 갯수이고 charAt는 맨앞에 글자주소를 0부터 읽는다.
//		//예시로 "안녕"은 길이는 2, '안'을 추출 할려면 charAt(0),'녕'을 추출할려면 charAt(1)
//	
//	
//	
//	
//	}
//}
