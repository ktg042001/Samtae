package temp;

public class For_test {

	public static void main(String[] args) {
		
		// 3행 2열 행렬을 가상하고 번호 붙이기
		int y = 0;
		for(int i = 0 ;i<3;i++) {
			for(int j=0;j<2;j++) {
				System.out.printf("<%d,%d,>",i,j); 
			}
			System.out.println();
		}
		
		
			
		
	}

}
