package temp;

public class Hello {

	public static void main(String[] args) {
		
		System.out.println("점심 뭐 드실래요?");
	
		
	}

}
